import { useAppSelector, useAppDispatch } from '../../../Hooks/useSelectorHooks';
import { communityActions } from '../CommunitySlice';
import Filter from '../../common/Filter/Filter';
import FilterDuration from '../../common/Filter/FilterDuration';
import WriteButton from '../components/WriteButton';
import FilterBox from '../../common/Filter/FilterBox';
import { useState } from 'react';

const FilterContainer = () => {
  const filter = useAppSelector((state) => state.CommunitySlice.filter);
  const addressFilterValue = useAppSelector((state) => state.CommunitySlice.addressFilter);
  const categoryFilterValue = useAppSelector((state) => state.CommunitySlice.categoryFilter);
  const Tab = useAppSelector((state) => state.CommunitySlice.tab);
  const dispatch = useAppDispatch();
  const setFilterAddressValue = (address: string) => dispatch(communityActions.setFilterAddressValue(address));
  const setFilterCategoryValue = (category: string) => dispatch(communityActions.setFilterCategoryValue(category));
  const setFilterAddressUse = (use: boolean) => dispatch(communityActions.setFilterAddressUse(use));
  const setFilterCategoryUse = (use: boolean) => dispatch(communityActions.setFilterCategoryUse(use));

  const setDurationShow = (show: boolean) => dispatch(communityActions.setFilterDurationShow(show));
  const setStartDate = (date: { year: number; month: number; day: number }) =>
    dispatch(communityActions.setFilterStartDate(date));

  const setEndDate = (date: { year: number; month: number; day: number }) =>
    dispatch(communityActions.setFilterEndDate(date));

  // redux 기간 설정 전 validation을 위한 상태
  const [startDateTarget, setStartDateTarget] = useState<{ year: number; month: number; day: number }>(
    filter.duration.StartDate,
  );
  // redux 기간 설정 전 validation을 위한 상태
  const [endDateTarget, setEndDateTarget] = useState<{ year: number; month: number; day: number }>(
    filter.duration.endDate,
  );

  const Today: Date = new Date();
  // 자유게시판으로 이동 시 필터 초기화
  if (Tab === '자유게시판') {
    setFilterAddressValue('지역');
    setFilterCategoryValue('카테고리');
    // setDurationYear(Today.getFullYear());
    // setDurationYear(Today.getFullYear(), true);
    // setDurationMonth(Today.getMonth() + 1);
    // setDurationMonth(Today.getMonth() + 1, true);
    // setDurationDay(Today.getDate());
    // setDurationDay(Today.getDate(), true);
    return <div></div>;
  } else {
    return (
      <FilterBox>
        <Filter
          value={categoryFilterValue.value}
          onChange={(e) => {
            setFilterCategoryValue(e.target.value);
            setFilterCategoryUse(true);
          }}
          Options={['카테고리', '의류', '주류', '캐릭터']}
          width={23}
        />
        <Filter
          value={addressFilterValue.value}
          onChange={(e) => {
            setFilterAddressValue(e.target.value);
            setFilterAddressUse(true);
          }}
          Options={[
            '지역',
            '서울',
            '부산',
            '대구',
            '인천',
            '광주',
            '대전',
            '울산',
            '세종',
            '경기도',
            '강원도',
            '충청도',
            '전라북도',
            '전라남도',
            '경상북도',
            '경상남도',
            '제주',
          ]}
          width={23}
        />
        <FilterDuration
          show={filter.duration.show}
          setShow={() => {
            setDurationShow(!filter.duration.show);
          }}
          setStartDate={setStartDate}
          setEndDate={setEndDate}
          startDateTarget={startDateTarget}
          setStartDateTarget={setStartDateTarget}
          endDateTarget={endDateTarget}
          setEndDateTarget={setEndDateTarget}
        />
        <WriteButton />
      </FilterBox>
    );
  }
};

export default FilterContainer;
